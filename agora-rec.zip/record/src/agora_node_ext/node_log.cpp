/*
* Copyright (c) 2017 Agora.io
* All rights reserved.
* Proprietry and Confidential -- Agora.io
*/

/*
*  Created by Wang Yongli, 2017
*/

#include <stdio.h>
#include <stdarg.h>
#include "node_log.h"

void log(enum log_level level, const char *format, ...)
{
    // TBD
    /*va_list la;
    va_start(la, format);
    vprintf(format, la);
    va_end(la);*/
}
